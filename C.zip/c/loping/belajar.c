#include <stdio.h>
int main()
{
    int i, j, k, n;
    printf("masukkan angka: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (k = n; k > i; k--)
            printf(" ");
        for (j = 1; j <= (2 * i) - 1; j++)
            printf("*");
        printf("\n");
    }
    printf("\n");

    return 0;
}